<html>
<head>
<title>Voided Alliance Installer</title>
</head>
<body>
<h2>Voided Alliance Installer</h2>
<h4>To begin, you might need to CHMOD installer.php to 777 (Change the Permissions) and make sure the SQL.sql.txt is readable.<br> Otherwise you will get errors after the installer while running the game. <br> Then fill out the form below. <br> If you do not know your username and password ,ask your web server administerator,</h4>
<form action="installer.php" method="post">
Database Host: <input type="text" name="datahost" /><br />
Database Name: <input type="text" name="dataname" /><br />
Database Username: <input type="text" name="datauser" /><br />
Database Password: <input type="password" name="datapass" /><br />
<br />
Administrator Username: <input type="text" name="adminuser" disabled="true" value="admin" /><br />
Administrator Password: <input type="password" name="adminpass" /><br />
<button type="submit">Install</button>
</form>
<h5>Voided Alliance 2008 
<br> All Rights Reserved to: 
<br> <a href="http://www.auburnflame.com">Auburnflame Productions</a>
<br>
<br>
Special thanks to:
<br><a href="http://www.worldhigh.com/">Worldhigh Productions</a> and <a href = "http://coruscant.ej.am/">James Everett</a>.</h5>
</body>
</html>